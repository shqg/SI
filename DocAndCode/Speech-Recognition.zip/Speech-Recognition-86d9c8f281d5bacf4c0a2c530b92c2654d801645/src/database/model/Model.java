package database.model;


public interface Model {
	public String getName();
	public String getExtension();
}
